function [u,s,v] =my_svd_fast(A)
    [n, m] = size(A);
    if n > m
        [v,d] = eig(A'*A);
        vecd = diag(d);
        vecd = vecd  + 10^-11;
        vecd = vecd.^(1/2);
        s = diag(vecd);
        inv_s = diag(1./vecd);
        u = A*v*inv_s;
    else
        [u,d] = eig(A*A');
        vecd = diag(d);
        vecd = vecd  + 10^-11;
        vecd = vecd.^(1/2);
        s = diag(vecd);
        inv_s = diag(1./vecd);
        vt = inv_s*(u'*A);
        v = vt';
    end

    ss = diag(s);
    [~,ind] = sort (ss,'descend');
    ss = ss(ind);
    s = diag(ss);
    u = u(:,ind);
    v = v(:,ind);
end