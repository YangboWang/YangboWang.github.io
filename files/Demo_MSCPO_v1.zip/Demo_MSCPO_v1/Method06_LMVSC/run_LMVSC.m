clc;clear;
load return_seeds_LAEC_v2;
strDatasets = {
    'dig1-10'
}; 
strMethods  = "LMVSC";
for dataseti = 1:1:length(strDatasets)
    dataName = strDatasets{dataseti};
    load(dataName);
    addpath('./funs_LMVSC/');
    X = {X};
    nv      = length(X);
    c       = length(unique(gnd));
    r_list  = [c,50,100];
    alpha_list= 10.^[-3 -2 -1 0 1];
    for ii=1:nv
        X{ii} = X{ii} - ones(size(X{ii},1),1)*min(X{ii});
        X{ii} = X{ii}./( ones(size(X{ii},1),1)*max(X{ii}) + eps);
    end
    Records = [];
    for sdi = 1:1:length(seeds)
        
        seedi = seeds(sdi);
        step = 0;
        Record  = [];
        for ri =1:1:length(r_list)
            r = r_list(ri);
                parfor i=1:nv
                    rand('twister',seedi);
                    [~, H{i}] = litekmeans_lmv(X{i},r,'MaxIter', 100,'Replicates',10);
                end
            for alphai =1:1:length(alpha_list)
                alpha = alpha_list(alphai);
                step = step + 1;
                parfor i=1:nv
                    rand('twister',seedi);
                    [~, H{i}] = litekmeans_lmv(X{i},r,'MaxIter', 100,'Replicates',10);
                end
                [F,ids,t] = lmv_v2(X',gnd,H,alpha,seedi);
                result = ClusteringMeasure_LAEC(ids,gnd);
                Record(step,:) =[step, r alpha result t];
                fprintf('step= %d: para: r = %d, alpha =%f, result:\t%12.6f %12.6f %12.6f %12.6f %12.6fs\n',Record(step,:));
            end
        end
        Records{sdi} = Record;
    end
    fprintf('Dataname = %s', dataName);

%     seeds = [1];
    mean_Record =[];
    mean_Record = Records{1}(:,1:3);
    std_Record =[];
    std_Record = Records{1}(:,1:3);
    for j =4:1:8
        ret = [];
        for sdi = 1:1:length(seeds)
             ret= [ret,Records{sdi}(:,j)];
        end
        mean_Record = [mean_Record,mean(ret,2)];
        std_Record  = [std_Record,std(ret,0,2)];
    end
    mean_datai_Record{dataseti} = mean_Record;
    std_datai_Record{dataseti} = std_Record;
    
    [~,ind] = max(mean_Record(:,4:4));
    opt_AVE(dataseti,1:8) = mean_Record(ind,:);
    opt_STD(dataseti,1:8) = std_Record(ind,:);

    mean_Record
    clear X
    clear gnd
    filename =  "results_"+ dataName +"_"+strMethods;
    save(filename, "Records","mean_datai_Record","std_datai_Record","opt_AVE","opt_STD");
end