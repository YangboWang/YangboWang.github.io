
clc;clear;
load return_seeds_LAEC_v2;
strDatasets = {
    'dig1-10'
    'optdigit_5620n_10c_64d'
    'warpPIE10P'
    'Jaffe_213n_10c_1024d'
    'YaleB_2414d_38c_1024d'
    'CMUPIE_3329n_68c_1024d'
    'PIE_11560n_68c_1024d'
    'SVHN_test_26032n_1024d_10c'
    'SVHN_train_73257n_1024d_10c'
}; 
strMethods  = "MSCOPO";
for dataseti = 1:1:length(strDatasets)
    dataName = strDatasets{dataseti};
    load(dataName);
     addpath('./MSCOPO_func/');
    c       = length(unique(gnd));
    rL      = [10,20,40,70,100,150,200];
    if size(X,2) < 70
        rL      = [10,20,40];
    end 
    if size(X,2) < 40
        rL      = [10,20];
    end 
    if size(X,2) < 20
        rL      = [10];
    end 
    mL   = [1.1];
%     mL   = [1.1,1.3];
    gamL = 10^[3];
    Records = [];
    for sdi = 1:1:length(seeds)
        seedi = seeds(sdi);
        step = 0;
        Record = [];
        for ri =1:1:length(rL)
            r = rL(ri);
            for gami =1:1:length(gamL)
                gam = gamL(gami);
                for mi =1:1:length(mL)
                    m = mL(mi);
                    step = step + 1;
                    tic;
                    T = 100;
                    isNormalized = 1;
                    
                    [y,U,P,Ws,loss,results_step]= MSCOPO(X,gnd,isNormalized,r,gam,m,T,seedi);
                    t = toc;
                    result = ClusteringMeasure_LAEC(y,gnd);
                    Record(step,:) =[step, r gam m result t];
                    fprintf('step= \t%5.0d,  para: r = \t%5.2f, gamma = \t%5.2f, m =\t%5.2f, result:\t%12.6f %12.6f %12.6f %12.6f %12.6fs\n',Record(step,:));
                end
            end
        end
        Records{sdi} = Record;
    end
    fprintf('Dataname = %s', dataName);
    mean_Record =[];
    mean_Record = Records{1}(:,1:4);
    std_Record =[];
    std_Record = Records{1}(:,1:4);
    for j =5:1:9
        ret = [];
        for sdi = 1:1:length(seeds)
             ret= [ret,Records{sdi}(:,j)];
        end
        mean_Record = [mean_Record,mean(ret,2)];
        std_Record  = [std_Record,std(ret,0,2)];
    end
    mean_datai_Record{dataseti} = mean_Record;
    std_datai_Record{dataseti} = std_Record;
    
    [~,ind] = max(mean_Record(:,5:5));
    opt_AVE(dataseti,1:9) = mean_Record(ind,:);
    opt_STD(dataseti,1:9) = std_Record(ind,:);

    mean_Record
    clear X
    clear gnd
    filename =  "results_"+ dataName +"_"+strMethods;
    save(filename, "Records","mean_datai_Record","std_datai_Record","opt_AVE","opt_STD","results_step","loss");
end
