function [y,U,P,Ws,loss,results]= MSCPO(X,gnd,isNormalized,r,gam,m,T,seedi)
    
    if nargin < 8
        seedi = 1234;
    end
    if nargin < 7
        T = 100;
    end
    if nargin < 6
        m = 1.1;
    end
    if nargin < 5
        r = 20;
    end
    if nargin < 4
        gam = 100;
    end

    if isNormalized == 1
        X = X - ones(size(X,1),1)*min(X);
        X = X./(ones(size(X,1),1)*max(X) + eps);
    end
    c = length(unique(gnd));
    [n,d] = size(X);
%     rand('twister',seedi);
%     P     = rand(size(X,2),r);
    if size(X,1) > 3*10^4
        [u,s,v] = my_svd_fast(X);
    else
        [u,s,v] = svd(X);
    end
    
    P = v(:,1:r);
    rand('twister',seedi);
    U     = rand(n,c);
    E = (1./sum(U,2)).*ones(1,c);
    U = E.*U;
    for k =1:c
        uk = U(:,k);
        zk = uk.^(m/2);
        Xstark = (zk*ones(1,d)).*X;
        XtX{k} = Xstark'*Xstark;
    end
    results = [];
    loss = [];
    for iter =1:1:T
        % Update W{k}
        for k =1:c
            Ak =  XtX{k}*P;
            [u,s,v] = svd(Ak);
            Ws{k} = u(:,1:r)*v';
        end
        % Update P
        Tau     = gam*eye(d);
        Theta   = zeros(d,r);
        for k =1:c
            Tau   = Tau + XtX{k};
            Theta = Theta + XtX{k}*Ws{k};
        end
        P   = Tau \Theta; 
        % Update U
        old_U = U;
        D   = zeros(n,c) + 10^-15;
        for k =1:c
            D(:,k) = sum((X*P*Ws{k}' - X).^2,2);
        end
        uu  = 1/(m-1);
        z   = 1./( D.^uu);
        U   = z./(sum(z,2)*ones(1,c));
        [~,y] = max(U');
        y = y';
        % Update Xs
        for k =1:c
            uk = U(:,k);
            zk = uk.^(m/2);
            Xstar{k} = (zk*ones(1,d)).*X;
            XtX{k} = Xstar{k}'*Xstar{k};
        end
        %% loss
        loss(iter) = 0;
        for k =1:1:c
            gk = Xstar{k}*P*Ws{k}' - Xstar{k};
            loss(iter) = loss(iter) +(norm(gk,'fro'))^2;
        end
        loss(iter) = loss(iter) + gam*(norm(P,'fro'))^2;
%       loss(iter)
        if iter > 30 && abs(loss(iter) - loss(iter-5))/ loss(iter-5) < 10^-6
            break;
        end
    end
end

