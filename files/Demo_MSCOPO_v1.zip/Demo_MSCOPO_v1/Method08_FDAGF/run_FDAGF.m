clc;clear;

load return_seeds_LAEC_v2;
strDatasets = {
    'dig1-10'
}; 
strMethods  = "FDAGF";
for dataseti = 1:1:length(strDatasets)
    dataName = strDatasets{dataseti};
    load(dataName);
    addpath('./funcs_FDAGF/');
    X = {X};
    nv      = length(X);
    c       = length(unique(gnd));
    r_list  = c*[1:1:4];
    alpha_list=[10^-5 10^-1 10^1 10^3];
    lam_list=[10^1 10^3 10^5];
    Xt = [];
    for ii=1:nv
        X{ii} = X{ii} - ones(size(X{ii},1),1)*min(X{ii});
        X{ii} = X{ii}./( ones(size(X{ii},1),1)*max(X{ii}) + eps);
        Xt{ii} = X{ii}';
    end
    Records = [];
    for sdi = 1:1:length(seeds)
        seedi   = seeds(sdi);
        step    = 0;
        Record  = [];
        for alphai =1:1:length(alpha_list)
            alpha = alpha_list(alphai);
            for lami =1:1:length(lam_list)
                lam = lam_list(lami);
                step = step + 1;
%                 H = [];
                H = cell(nv,length(r_list));
                for ni=1:nv
                    for nj=1:length(r_list)
                        rand('twister',seedi);
                        [~, anc] = litekmeans_lmv(X{ni},r_list(nj),'MaxIter', 100,'Replicates',10);
                        H{ni,nj} = anc';
                    end
                end
                [ids,t] = algorithm_FDAGF(Xt,gnd,H,alpha,lam,r_list,seedi);
                result = ClusteringMeasure_LAEC(ids,gnd);
                Record(step,:) =[step, alpha lam result t];
                fprintf('step= %3d: para: alpha =\t%18.6f, lam =\t%12.2f, result:\t%12.6f %12.6f %12.6f %12.6f %12.6fs \n',Record(step,:));
            end
        end
        Records{sdi} = Record;
    end
    mean_Record = Records{1}(:,1:3);
    std_Record = Records{1}(:,1:3);
    for j =4:1:8
        ret = [];
        for sdi = 1:1:length(seeds)
             ret= [ret,Records{sdi}(:,j)];
        end
        mean_Record = [mean_Record,mean(ret,2)];
        std_Record  = [std_Record,std(ret,0,2)];
    end
    mean_datai_Record{dataseti} = mean_Record;
    std_datai_Record{dataseti} = std_Record;
    
    [~,ind] = max(mean_Record(:,4:4));
    opt_AVE(dataseti,1:8) = mean_Record(ind,:);
    opt_STD(dataseti,1:8) = std_Record(ind,:);
    
    dataName
    mean_Record
    clear X
    clear gnd
    filename =  "results_"+ dataName +"_"+strMethods;
    save(filename, "Records","mean_datai_Record","std_datai_Record","opt_AVE","opt_STD");
end