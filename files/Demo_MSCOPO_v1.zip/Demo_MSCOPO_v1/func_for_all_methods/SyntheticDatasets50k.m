clc;clear;
seed = 1234;
rand('twister',seed);
SEEDS = randi([1,10000], 1, 10);
% 50k, 200k, 500k, 1m,2m, 10m
n = 10*10^3;
% d = 50;
% r = 5;
d = 40;
r = 5;
c  = 10;
P = [];
for i =1:1:c
    seedi = SEEDS(i);
    mu  = 1;
    eta = 0.1;
    P{i} = generate_Pro_Matrix(d,r,seedi,mu,eta);
end
X = [];
gnd = [];
for i =1:1:c
   seedi = SEEDS(i);
   rand('twister',seedi);
   data = i/c + randn(n, r);
   X   =   [X; data*P{i}' + 0.05*randn(n, d)];
   gnd =   [gnd; ones(n,1)*i];
end
% imagesc(X*X')
% X = zscore(X);

% nn = size(X,1);
% X = X - ones(nn,1)*min(X);
% X = X./(ones(nn,1)*max(X) + eps);

% [y,V] = kmeans(X,c);
% result = ClusteringMeasure_LAEC(gnd,y)
% 
% b = mean(X');
% plot(b)
% plot(sum(abs(X)'))
% mTsne(X,gnd)

save('SyntheticDatasets_multi_subspace_10m','X','gnd')