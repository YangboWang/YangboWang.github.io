function [P] = generate_Pro_Matrix(d,r,seedi,mu,eta)
%     rand('twister',seedi);
%     % 设置参数
%     mu    = zeros(1, r); % 20维均值为0
%     sigma = 0.1; % 方差为0.1
%     covarianceMatrix = sigma * eye(r); % 20维的协方差矩阵
%     
%     % 生成符合正态分布的数据
%     P = mvnrnd(mu, covarianceMatrix, d); % 生成100个样本
% %     P = orth(P);

    rand('twister',seedi);
    P= mu + eta * randn(d, r);
%     % 设置参数
%     mu    = zeros(1, r); % 20维均值为0
%     sigma = 0.1; % 方差为0.1
%     covarianceMatrix = sigma * eye(r); % 20维的协方差矩阵
%     
%     % 生成符合正态分布的数据
%     P = mvnrnd(mu, covarianceMatrix, d); % 生成100个样本
    P = orth(P);
end