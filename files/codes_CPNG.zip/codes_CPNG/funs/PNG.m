
function [W,P] = PNG(X,r,m,k,NITER)

    [num,dim] = size(X);          
    
    [W, mu, idx, distX] = Adaptive_Graph_Construct_S(X', k);  % ͨ������Ӧͼ�ķ�����ʼ�����ƶȾ��� cite{Nie2014}
    % imagesc(W);
    XTX = X'*X + eye(dim)*0.001;
    invXTX = inv(XTX);
    
    W = (W+W')/2;
    D = diag(sum(W));
    L = D - W;
    P = eig1(X'*L*X, r, 0, 0);
    
    eta = zeros(1,num);
    %     mTsne(X*P,gnd);
    for iter = 1:NITER
        XP = X*P;
        distxp = L2_distance_1(XP',XP');
        if iter>5
            [temp, idx] = sort(distxp,2);
        end
        W = zeros(num);
        for i=1:num
            idxa0   = idx(i,2:k+1);
            eta(i)  = max(distxp(i,idxa0));
            di      = distxp(i,idxa0);
            W(i,idxa0) = 1 - (di/(eta(i)*m)).^(1/(m-1));
        end
        % imagesc(W);
        W = (W+W')/2;
        D = diag(sum(W));
        L = D - W;
        P = eig1(invXTX*(X'*L*X), r, 0, 0);
    end
end
