function [y,ret_cent,Record,id] = mkmeans(X, c, num)
    

    n = size(X,1);  
    d = size(X,2);
    Record = [];
    opt_obj = 10^8;
    for j = 1:num

        [ind, cent]= kmeans(X,c);
        X1 = zeros(n,d);
        for i =1:n
            indi = ind(i);
            X1(i,:) = cent(indi,:);
        end
        obj = norm( X - X1, 'fro' ); %
        Record{j} = { obj, ind, cent}; 
        if obj < opt_obj
            opt_obj =obj;
            id = j;
        end
    end
    y = Record{id}{2};
    ret_cent = Record{id}{3};
end