clc; clear;
load './iris/data.txt';
load './iris/gnd.txt';

X           = data;
c           = length(unique(gnd)); 
[n,d]       = size(X);
rL          = [2:1:d];
m = 1.5; 
NeighborK   = 10; 
MaxStep     = 30;
%% CPNG
optACC  = 0;
step    = 0; 
Record  = []; 
Paras =[];
for ri =1:1:length(rL)
    r = rL(ri);
    step = step + 1;

    [W0,P] = PNG(X,r,m,NeighborK,MaxStep);
    W   = (W0+W0')/2;
    D   = diag(sum(W));
    D_  = (D + 10^-5*eye(n))^(-1/2);
    L   = eye(n) - D_*W*D_;
    F   = eig1(L, c, 0, 0);
    if ~ isreal(F)
        continue;
    end
    [y_,cent_,~,~] = mkmeans(F, c, 20);

    acc_ = ACC2(gnd,y_,c);
    nmi_ = NMI(gnd,y_);
    Record = [Record; [step,NeighborK,r,m,nmi_,acc_]];
    fprintf('Step (CPNG): id=%d, k = %d, r = %d, m = %f,Nmi = %f, acc = %f\n',step,NeighborK,r,m,nmi_,acc_);
    if acc_> optACC 
        optACC  = acc_;
        Paras = {step,NeighborK,r,m,nmi_,acc_,P,W0,F,y_,cent_};
    end
end
  










